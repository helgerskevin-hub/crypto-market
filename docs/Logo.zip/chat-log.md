# Crypto Copy-Trading — Design System · Chat log

---

## Gebruiker

> create a design system for the app idea i attached. below more context:
>
> Een paar dingen die helpen nu we naar React Native gaan (echte native componenten i.p.v. de WebView van nu):
>
> Begin met de bestaande designcontext. Lees CONTEXT.md en docs/app-beschrijving-voor-claude-design.md: daar staan het donkere "fintech/dashboard"-thema, de kleur-tokens en de schermen al beschreven. Die blijven het uitgangspunt; we herbouwen alleen de techniek eronder.
>
> Stijl-/componentlaag kiezen: React Native Paper (Material 3) of NativeWind.
> Navigatie: react-navigation met bottom tabs voor Marktanalyse, Grote kansen, Mijn Trades, eToro-traders + onboarding-flow.
> Per scherm aan te leveren: de vier states (leeg/laden/fout/gevuld), tokens als concrete waarden, iconenset/stijl.
> Cijferleesbaarheid is UX-kritisch: tabular-nums, groen/rood-codering, duidelijke hiërarchie.
> Grafieken: candlestick/lijn met trade-niveaus (entry, stop, take-profit).
> UX-kansen: onboarding, copy-trading in eenvoudigere stappen, score (0–100) begrijpelijk uitleggen.
> Vaste kaders: UI-taal Nederlands, sobere/heldere toon, "geen financieel advies"-disclaimer.
>
> Create the design system, then a design for every page of the app with a clear UX/UI flow.
> Don't use any AI design.

---

## Claude

Ik heb beide contextbestanden gelezen (CONTEXT.md en app-beschrijving-voor-claude-design.md). Voordat ik begin, zijn er een paar keuzes die het hele systeem bepalen — in het bijzonder de spanning tussen het bestaande **donkere** fintech-thema en de **lichte** richting die het UX/UI-rapport aanbeveelt.

*→ Stuurde een vragenformulier met 10 vragen over thema, visuele taal, iconen, navigatiestructuur, schermen, states, grafieken, score-uitleg, variaties en eindproduct.*

---

## Gebruiker

*(Antwoorden op het vragenformulier)*

- **Thema:** Beide — bouw één systeem met light/dark-toggle (licht als default)
- **Visuele taal:** Decide for me
- **Iconen:** Volledig Lucide, geen emoji
- **Navigatie:** Er komen geen tabs meer, maar echt app-pagina's met het menu onderin. De tabs moeten hernoemd worden en verbeterd.
- **Schermen:** Alle schermen
- **States:** Alle 4 states (leeg/laden/fout/gevuld) voor élk scherm
- **Grafieken:** Decide for me
- **Score:** Decide for me
- **Variaties:** Eén doordachte richting, consistent uitgewerkt
- **Eindproduct:** Decide for me

---

## Claude

Richting vastgelegd:

- **Thema:** licht als default (Swiss Modernism + Executive Dashboard data), gedeelde dark-tokens → toggle
- **Visuele taal:** custom dashboard-tokens met Material-achtige navigatiepatronen (geen Material You look, maar eigen fintech karakter)
- **Iconen:** volledig Lucide (1.75px stroke), geen emoji
- **Navigatie:** 4 bottom-nav pagina's, hernoemd: **Markt · Kansen · Portfolio · Traders** + onboarding-flow ervóór
- **Typografie:** IBM Plex Sans (UI) + IBM Plex Mono (alle getallen/prijzen/score) — bewust niet Inter/Roboto
- **Spacing:** 8px-systeem (4/8/12/16/24/32)
- **Radii:** kaart 16px, knop 12px, pill 999px
- **Grafieken:** sparkline in trade-kaart + candlestick-detail met entry/stop/take-profit-niveaus + tijdframeselector
- **Score:** ring/meter (conic-gradient) + uitklapbare uitleg per band (0–39 zwak / 40–69 gemengd / 70–100 sterk)

*→ Begon bouw van het canvas-DC.*

---

## Bouw — wat er gemaakt is

### 01 Fundamenten

**Kleur-tokens licht (default)**

| Rol | Waarde |
|-----|--------|
| Achtergrond | `#F8FAFC` |
| Kaart | `#FFFFFF` |
| Verhoogd / muted | `#EEF2F7` |
| Rand / divider | `#E2E8F0` |
| Tekst primair | `#0F172A` |
| Tekst gedimd | `#64748B` |
| Primair / brand | `#1E3A8A` |
| CTA / interactief | `#2563EB` |
| Winst / koop | `#16A34A` |
| Verlies / stop | `#DC2626` |
| Let op | `#D97706` |
| Premium / goud | `#A16207` |

**Kleur-tokens donker**

| Rol | Waarde |
|-----|--------|
| Achtergrond | `#0E1117` |
| Kaart | `#161B22` |
| Verhoogd / muted | `#1C2230` |
| Rand / divider | `#2A3140` |
| Tekst primair | `#E6EDF3` |
| Tekst gedimd | `#8B949E` |
| Primair / brand | `#3B82F6` |
| CTA / interactief | `#2563EB` |
| Winst / koop | `#22C55E` |
| Verlies / stop | `#EF4444` |
| Let op | `#F59E0B` |

**Typografie**
- UI: IBM Plex Sans 400/500/600/700
- Getallen/prijzen: IBM Plex Mono met `tabular-nums` + `font-feature-settings:"tnum"`
- Body ≥ 15px, regelhoogte 1.5–1.6
- W/V altijd met expliciet teken (+/−), duizendtallen gescheiden

**Spacing:** 4 · 8 · 12 · 16 · 24 · 32 px

**Radii:** 8 (veld) · 12 (knop) · 16 (kaart) · 999px (pill)

**Elevatie:** rust (0 1px 2px) · kaart (0 4px 14px) · modal (0 12px 30px)

**Iconografie (Lucide, 1.75px stroke)**
Vervangt alle emoji als structurele iconen. Mapping:

| Oud emoji | Lucide icoon | Gebruik |
|-----------|-------------|---------|
| 📊 | activity / bar-chart | Markt tab |
| ⚡ | zap | Kansen tab |
| 💼 | wallet | Portfolio tab |
| 👥 | users | Traders tab |
| 📈 | trending-up | winst |
| 📉 | trending-down | verlies |
| 🎯 | target | take-profit |
| 🛑 | octagon | stop-loss |
| 🔔 | bell | melding |
| ✅ | check-circle | getrade |
| ⚠️ | alert-triangle | risico |

---

### 02 Kerncomponenten

**Trade-kaart (hero)**
- Border-left als stoplicht-indicator (groen/amber/rood = NEEM WINST / OVERWEEG / VERKOOP)
- Grote live prijs + gekleurd W/V % en €
- Voortgangsbalk stop ←→ entry ←→ doel met huidige-koers marker
- Drie mini-blokken: stop (rood tint) · entry (grijs) · doel (groen tint)
- R/R + RSI inline
- Advies-badge als pill

**Advies-badges (5 varianten)**
- VERKOOP NU → rood
- NEEM WINST → groen
- OVERWEEG WINST → amber
- HOUD VAST → slate
- LET OP → amber + alert-icoon

**eToro-oordeel pills**
- Kopieer → groen
- Volg → amber
- Vermijd → rood
(altijd met gekleurde cirkel + label — nooit kleur alleen)

**Signaalscore-meter**
- Conic-gradient ring: groen (70–100) / amber (40–69) / rood (0–39)
- Getal in het midden + band-label (STERK / GEMENGD / ZWAK)
- Uitklapbare uitleg per onderdeel

**KPI-samenvatting (max 5 cellen)**
Open · Ingelegd · Waarde · Totaal W/V · Actie nodig

**Bottom nav (4 items)**
Markt · Kansen · Portfolio · Traders — icoon 22px + label 10.5px, actief item in brandkleur

**Grafieken**
- Sparkline: line + area-fill (20% opacity), kleur op W/V
- Candlestick: gevuld bullish / hol bearish (kleurenblind-veilig), entry/stop/TP als gekleurde dashed horizontals + tekstlabel

---

### 03 Onboarding (5 stappen)

1. **Welkom** — dark splash, groot app-logo, tagline, "Aan de slag"-knop
2. **Hoe het werkt** — 3 feature-cards (Markt analyseren / eToro-traders / Op tijd gewaarschuwd)
3. **Disclaimer (akkoord vereist)** — waarschuwingsicoon, 2 checkpunten, checkbox "Ik begrijp en ga akkoord"
4. **Meldingen** — uitleg take-profit / stap-eerder-uit, "Meldingen toestaan" + "Niet nu"
5. **Klaar** — groen check, CTA "Naar Markt →"

Progress dots per stap. Disclaimer-stap blokkeert doorgaan zonder akkoord.

---

### 04 Markt (Marktanalyse) — 4 states

**Gevuld**
- Analyseresultaten (12 coins geanalyseerd)
- Kanskaarten met score-ring, entry/stop/doel blokken, R/R + RSI, advies-badge, "Over deze coin" uitklap, "Getrade" + "Aanpassen" knoppen
- Border-left kleur = signaalsterkte

**Leeg**
- Grote Markt-icoon, uitlegtekst, "Start analyse"-knop
- Disclaimer footer

**Laden**
- Spin-indicator "Markt analyseren…"
- Skeleton-kaarten met shimmer-animatie

**Fout**
- Wifi-off icoon, "Binance en CoinGecko niet bereikbaar", "Opnieuw proberen"
- Timestamp laatste poging

---

### 05 Kansen (Grote kansen) — 4 states

**Gevuld**
- Amber risico-banner bovenaan (speculatief, hoog risico)
- Kandidaatkaarten: coin + marktcap, momentum % badge, mini-stats (momentum/tot ATH/volume), "Waarom"-uitleg, speculatief-pill, "Bekijk"-knop

**Leeg**
- Zap-icoon, uitleg, amber disclaimer-blok, "Scan starten"

**Laden**
- Progress bar (524/847 coins), skeleton-kaarten

**Fout**
- "Scan onderbroken", "Scan opnieuw"

---

### 06 Portfolio (Mijn Trades) — 4 states

**Gevuld**
- "+ Trade"-knop in header
- 3-cel KPI-strip (Waarde / Totaal W/V / Actie)
- Pushmeldingen-kaart: toggle (aan), status-pill "gecontroleerd · 14:30 UTC", "Testmelding"-knop
- Trade-kaart (hero): stoplicht-rand, live prijs, W/V, voortgangsbalk, advies-tekst + badge, knoppen

**Leeg**
- Wallet-icoon, "Nog geen trades", "Trade toevoegen"

**Laden**
- Header spin, KPI-skeletons, meldings-skeleton, trade-skeleton

**Fout** (prijzen verouderd)
- Rood waarschuwingsbanner "Prijzen niet bijgewerkt · van 14:18"
- Trade-kaart gedimmed met timestamp
- "Prijzen vernieuwen"-knop

---

### 07 Traders (eToro) — 4 states

**Gevuld**
- Trader-kaart met grote score-ring /100 + verdict-pill (Kopieer / Volg / Vermijd)
- Copy Stop Loss % in groen-tint blok
- Drie voortgangsbalken: Consistentie / Risico / Spreiding
- "Kopieer in 3 stappen"-knop
- 3-stappen stepper: Bedrag kiezen → Stop-loss instellen → Op eToro bevestigen

**Leeg**
- Users-icoon, "Beoordeel een trader"

**Laden**
- Score-ring skeleton, breakdown skeletons

**Fout**
- "Posities niet geladen — beoordeling blijft bewaard", "Opnieuw proberen"

---

### 08 Trade-detail met grafiek — 4 states

**Gevuld**
- Back-header (geen bottom nav — pushed screen), coin + "live"-badge
- Grote prijs + W/V
- Candlestick-grafiek met gekleurde dashed niveaulijnen + tekstlabels rechts (TP/entry/stop) + huidige-koers marker
- Tijdframeselector (1u · 4u · 1d · 1w)
- 3-koloms niveaustrip (stop/entry/doel)
- Advies-blok met uitlegtekst + disclaimer
- Sticky action bar (Gesloten markeren / Aanpassen)

**Leeg**
- "Nog geen grafiekdata" icoon + uitleg; niveaus wél zichtbaar

**Laden**
- Chart-skeleton, spin "Koershistorie laden…"

**Fout**
- "Grafiek niet beschikbaar — trade ongewijzigd", "Opnieuw laden"

---

### 09 Dark mode — toggle-bewijs (3 schermen)

- **Markt gevuld (dark):** dezelfde layout, donkere tokens, groen/rood iets lichter voor donkere achtergrond, nav met accent blauw
- **Portfolio gevuld (dark):** trade-kaart met donkere border-left, pushmelding-kaart dark, KPI-strip dark
- **Lockscreen-meldingen:** twee native Android-notificaties met glasmorphism-card, SOL take-profit verhogen + BTC stap eerder uit
- **Toggle-card:** licht/donker keuze + "Volg systeeminstelling" schakelaar + WCAG-waarschuwing

---

## UX-beslissingen (onderbouwing)

| Beslissing | Reden |
|-----------|-------|
| IBM Plex Mono voor getallen | Tabular-nums + technisch karakter, onderscheidend van Inter-slop |
| Lucide iconen, geen emoji | Schaalbaarheid, aria-label, consistentie op alle densities |
| Border-left als advies-indicator | Onmiddellijk zichtbaar zonder de kaart te openen (kleur + positie) |
| Score-ring i.p.v. getal | Snel begrijpbaar, band-label erbij (STERK/GEMENGD/ZWAK) |
| Disclaimer op stap 3 onboarding | Akkoord vereist vóór eerste analyse — juridisch relevant |
| Portfolio-fout toont verouderde data | Beter dan lege staat: gebruiker kan nog steeds besluiten nemen |
| 3-stappen copy-trading stepper | Makkelijkere stappen = TODO uit de brief |
| Geen emoji als structurele iconen | Skill-richtlijn: Lucide SVG + aria-label voor toegankelijkheid |
| Kleur nooit als enig signaal | WCAG 1.4.1: altijd + label of vorm-icoon erbij |
| Raakdoelen ≥ 44×44px | iOS HIG + Android Material minimum |

---

## Vaste kaders (ongewijzigd)

- UI-taal **Nederlands** — alle labels, states en copy
- **"Geen financieel advies"** disclaimer zichtbaar op: onboarding stap 3, lege Markt-state, detail-grafiek advies-blok, lockscreen-melding footer
- **"Check de live koers op eToro"** bij elk koop-/verkoopadies
- Toon: **nuchter en behulpzaam**, nooit hypend ("to the moon")

---

*Gegenereerd met Claude — Crypto Copy-Trading Design System · juni 2025*
